# Reproducibility pack: tb-hiv-ipt

Generated: 20260420T164441Z UTC
Bundle version: 0.2.0-plan-A

## What's in here

- `paper/` — the paper files as of when this pack was built.
- `pins.json` — the exact Ollama / Python / model versions used. To reproduce the exact local AI stack, install these pinned versions.
- `sentinel-findings.jsonl` — pre-push scan history against the rule library (P0 BLOCK, P1 WARN). Shows what the guardrails caught.
- `ai_calls_filtered.jsonl` — audit log of AI-assisted calls made during authoring. Hashes only — no raw prompt or response text.
- `consent_fingerprint.json` — SHA256 of (name|email) + AGREE timestamp. Establishes who authored without leaking PII.
- `manifest.json` — SHA256 of every file in this pack. Tamper-evident.
- `ro-crate-metadata.json` — RO-Crate 1.2 JSON-LD manifest, makes this pack portable to any FAIR-compliant institutional repository.
- `baseline.json` (if present) — numerical baseline corpus for this paper. Used by `student baseline check` to detect numerical drift.

## How to verify this pack

```
python -c "import hashlib, json; m = json.load(open('manifest.json')); print('OK' if all(hashlib.sha256(open(f,'rb').read()).hexdigest() == h for f, h in m['files'].items() if f != 'manifest.json') else 'FAIL')"
```

## How to reproduce the AI setup

Install Ollama at the version pinned in `pins.json`, pull the models at the digests pinned there, then run the e156 student starter at the `bundle_version` printed above against the `paper/` directory.
